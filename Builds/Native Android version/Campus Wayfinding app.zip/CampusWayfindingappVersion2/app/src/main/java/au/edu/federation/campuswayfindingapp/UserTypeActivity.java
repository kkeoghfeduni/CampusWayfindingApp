package au.edu.federation.campuswayfindingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;


import androidx.appcompat.app.AppCompatActivity;

public class UserTypeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usertype);
    }
    public void buttonPress(View v) {

        Intent intent = new Intent (this, HomeActivity.class);
        startActivity(intent);
    }

    public void staffButtonPress(View v) {

        Intent intent = new Intent (this, StaffActivity.class);
        startActivity(intent);
    }
}
